package com.mtool.view;


import com.mtool.bean.GroupMemberBean;

/**
 * Created by sshss on 2017/12/8.
 */

public interface IGroupMemberView extends IView {
    void showMembers(GroupMemberBean bean);

}
